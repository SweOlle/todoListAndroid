package com.example.todolist

import android.graphics.Paint.Align
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.todolist.ui.theme.TodoListTheme

val toDoRepository = ToDoRepository().apply {
    // Let's add two initial ToDos (to facilitate testing)
    addToDo(
        "Feed the pets",
        "Give the cat a fish and the dog a cat."
    )
    addToDo(
        "Exercise",
        "Take a walk and listen to music."
    )
}

class ToDoRepository {

    private val toDos = mutableListOf<ToDo>()

    fun addToDo(title: String, content: String): Int {

        val id = when {
            toDos.isEmpty() -> 1
            else -> toDos.last().id + 1 // We increment id by 1
        }
        toDos.add(ToDo(
            id,
            title,
            content
        ))
        return id
    }

    fun getAllTodos(): List<ToDo> {
        return toDos
    }

    fun getToDoById(id: Int): ToDo? {
        return toDos.find { it.id == id }
    }

    fun deleteToDo(id: Int): Boolean {
        return toDos.removeIf { it.id == id }
    }

    fun updateToDo(id: Int, title: String, content: String): Boolean {
        val index = toDos.indexOfFirst { it.id == id }

        if (index != -1) {
            toDos[index] = ToDo(id, title, content) // We assign a new object to the "spot" because when using data class the properties are not mutable
            return true
        }
        return false
    }

}

data class ToDo(val id: Int, val title: String, val content: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val navController = rememberNavController()

            TodoListTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colors.background
                ) {
                    NavHost(navController = navController, startDestination = "viewAll"){
                        composable("viewAll"){
                            ViewAllScreen(navController = navController)
                        }
                        composable("viewOne/{id}"){
                            val id = it.arguments!!.getString("id")!!.toInt()
                            ViewOneScreen(id = id, navController = navController)
                        }
                        composable("addToDo"){
                            AddNewToDoScreen(navController = navController)
                        }
                        composable("updateToDo/{id}"){
                            val id = it.arguments!!.getString("id")!!.toInt()
                            UpdateToDoScreen(navController = navController, id = id)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ViewAllScreen(navController: NavHostController) {
    Box(
        modifier = Modifier
            .fillMaxSize()
    ){
        LazyColumn{
            val toDos = toDoRepository.getAllTodos()
            items(toDos.size){ index ->
                val toDo = toDos[index]
                Button(onClick = { navController.navigate("viewOne/${toDo.id}") }) {
                    Text(toDo.title)
                }

            }
        }
        Button( modifier = Modifier .align(Alignment.TopEnd), onClick = { navController.navigate("addToDo") }) {
            Text("Create New ToDo")
        }
    }



}

@Composable
fun ViewOneScreen(id: Int, navController: NavHostController) {

    val toDo = toDoRepository.getToDoById(id)

    if(toDo!=null){
        Box(modifier = Modifier
            .fillMaxSize()
        ){
            Column(modifier = Modifier .align(Alignment.Center)){
                Text(
                    text = toDo.title
                )
                Spacer(modifier = Modifier .height(12.dp))
                Text(
                    text = "Description: ${toDo.content}"
                )
            }

            Button( modifier = Modifier .align(Alignment.TopEnd), onClick = { navController.navigate("viewAll") }) {
                Text("Go Back")
            }

            Button( modifier = Modifier .align(Alignment.BottomEnd), onClick = {
                toDoRepository.deleteToDo(id = id)
                navController.navigate("viewAll")

            }) {
                Text("Delete ToDo")
            }

            Button( modifier = Modifier .align(Alignment.TopStart), onClick = {
                navController.navigate("updateToDo/${toDo.id}")

            }) {
                Text("Update")
            }

        }
    }
}

@Composable
fun UpdateToDoScreen(navController: NavHostController, id: Int) {

    val toDo = toDoRepository.getToDoById(id)

    if (toDo!=null){

        val newTitle = remember { mutableStateOf(toDo.title) }
        val newContent = remember { mutableStateOf(toDo.content) }

        var error = ""

        val titleLengthValidMin = remember { mutableStateOf(newTitle.value.length > 3) }
        val titleLengthValidMax = remember { mutableStateOf(newTitle.value.length < 50) }
        val contentLengthValid = remember { mutableStateOf(newContent.value.length < 120) }

        Box(modifier = Modifier
            .fillMaxSize()
        ){
            Column(modifier = Modifier .align(Alignment.Center)) {
                TextField(
                    value = toDo.title,
                    onValueChange = {
                        newTitle.value = it
                        titleLengthValidMin.value = it.length >= 3
                        titleLengthValidMax.value = it.length <= 50
                                    },
                    label = { Text("Title") },
                )
                if (!titleLengthValidMax.value || !titleLengthValidMin.value) { error = "Title should be between 3 and 50 characters" }
                TextField(
                    value = toDo.content,
                    onValueChange = {
                        newContent.value = it
                        contentLengthValid.value = it.length <= 120 },
                    label = { Text("Content") },
                )
                if (!contentLengthValid.value) { error = "Content should be at most 120 characters long" }
                if (error.isNotEmpty()) {
                    Text(error, style = MaterialTheme.typography.body1)
                }
                Button(
                    onClick = {
                        if (titleLengthValidMax.value && titleLengthValidMin.value && contentLengthValid.value) {
                            toDoRepository.updateToDo(id = id, title = newTitle.value, content = newContent.value)
                            navController.navigate("viewOne/${toDo.id}")
                        }
                    },
                ){
                    Text("Update ToDo")
                }

            }
            Button( modifier = Modifier .align(Alignment.TopEnd), onClick = { navController.navigate("viewOne/${toDo.id}") }) {
                Text("Go Back")
            }
        }
    }
}

@Composable
fun AddNewToDoScreen(navController: NavHostController) {
    val newTitle = remember { mutableStateOf("") }
    val newContent = remember { mutableStateOf("") }

    var error = ""

    val titleLengthValidMin = remember { mutableStateOf(newTitle.value.length > 3) }
    val titleLengthValidMax = remember { mutableStateOf(newTitle.value.length < 50) }
    val contentLengthValid = remember { mutableStateOf(newContent.value.length < 120) }

    Box(modifier = Modifier
        .fillMaxSize()
    ){
        Column(modifier = Modifier .align(Alignment.Center)) {
            TextField(
                value = "",
                onValueChange = { newTitle.value = it
                    titleLengthValidMin.value = it.length >= 3
                    titleLengthValidMax.value = it.length <= 50},
                label = { Text("Title") },
            )
            if (!titleLengthValidMax.value || !titleLengthValidMin.value) { error = "Title should be between 3 and 50 characters" }
            TextField(
                value = "",
                onValueChange = { newContent.value = it
                    contentLengthValid.value = it.length <= 120 },
                label = { Text("Content") },
            )
            if (!contentLengthValid.value) { error = "Content should be at most 120 characters long" }
            if (error.isNotEmpty()) {
                Text(error, style = MaterialTheme.typography.body1)
            }
            Button(
                onClick = {
                    if (titleLengthValidMax.value && titleLengthValidMin.value && contentLengthValid.value) {
                        toDoRepository.addToDo(title = newTitle.value, content = newContent.value)
                        navController.navigate("viewAll")
                    }
                })
            {
                Text("Create ToDo")
            }

        }
        Button( modifier = Modifier .align(Alignment.TopEnd), onClick = { navController.navigate("viewAll") }) {
            Text("Go Back")
        }
    }
}

@Composable
fun Greeting(name: String) {
    Text(text = "Hello $name!")
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    TodoListTheme {
        Greeting("Android")
    }
}


// Validation for creating?